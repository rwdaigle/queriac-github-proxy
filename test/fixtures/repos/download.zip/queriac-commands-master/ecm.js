// Earth Class Mail

location = "https://secure.earthclassmail.com/login.aspx"