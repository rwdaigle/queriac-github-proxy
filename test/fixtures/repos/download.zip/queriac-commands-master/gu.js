// GitHub User Quickjump

/*
Jump directly to a Github user profile
*/

location = "https://github.com/"+args[0];