// Show NPM Module

location="https://npmjs.org/package/"+args[0];