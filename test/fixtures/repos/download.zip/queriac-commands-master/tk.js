// Typekit Font Search

location = "https://typekit.com/search?utf8=%E2%9C%93&q="+args.join(" ");