// Flickr Search

/*
Search flickr by tags, text and/or user.
*/

location = "http://flickr.com/search/?q="+args.join(" ");