// Google Search for Adobe's AS3 LiveDocs

/*
Adobe's LiveDocs servers are generally very slow, and there doesn't seem to be a way to restrict searches to a specific technology, but this Google search helps get past that, at least for AS3 documentation
*/

http://www.google.com/search?q=site:http://livedocs.adobe.com/flash/9.0/ActionScriptLangRefV3 (q)