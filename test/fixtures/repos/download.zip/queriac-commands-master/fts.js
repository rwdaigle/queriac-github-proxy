// Flickr Tag Search (Everyone's Photos)

http://flickr.com/search/?w=all&q=(q)&m=tags