// BackType the Current Page

/*
BackType is a service that lets you find, follow and share comments from across the web. Whenever you fill out the "Website" or "URL" field in a comment form when you publish a comment on a blog or other website, BackType attributes it to you. We give comment authors a profile featuring all the comments they've written on the Internet. If you don't have a website to use when you fill out comment forms, sign up and use one of ours.
*/

location.href='http://www.backtype.com/connect/'+encodeURIComponent(location.href.substring(7).replace(new%20RegExp('/','g'),'%252f'))+'&referrer';