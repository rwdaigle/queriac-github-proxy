// Word Count

(function()%7Bvar%20T=%7B%7D,W=%5B%5D,C=0,s,i;%20function%20F(n)%7Bvar%20i,x,a,w,t=n.tagName;if(n.nodeType==3)%7Ba=n.data.toLowerCase().split(/%5B%5Cs%5C(%5C)%5C:%5C,%5C.;%5C%3C%5C%3E%5C&%5C'%5C%22%5D/),i;for(i%20in%20a)if(w=a%5Bi%5D)%7Bw=%22%2
