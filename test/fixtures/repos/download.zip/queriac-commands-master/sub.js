// Subscribe with Google Reader

location = 'http://www.google.com/ig/add?feedurl='+encodeURIComponent(location.href);