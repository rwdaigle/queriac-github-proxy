// Resize Browser Window to 1280x800

javascript:resizeTo(1280,800)