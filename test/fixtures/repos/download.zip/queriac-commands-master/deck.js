// GistDeck

(function(){
  var s=document.createElement('script');
  s.setAttribute('src','https://gistdeck.herokuapp.com/gistdeck.js');
  document.getElementsByTagName('head')[0].appendChild(s);
})();