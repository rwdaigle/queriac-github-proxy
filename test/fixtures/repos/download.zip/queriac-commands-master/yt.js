// Youtube Quicksearch

location = 'http://www.youtube.com/results?search_query='+args.join(" ");