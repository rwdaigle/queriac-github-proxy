// Github Code Search

location="https://github.com/search?ref=simplesearch&type=Code&q="+args.join(" ")