// Twitter Search

/*
See what's happening - right now. 

Examples
#current near:93101
cool filter:links
"is down"
#haiku
"listening to"
obama OR mccain
*/

location='https://twitter.com/search?q='+args.join(" ");

