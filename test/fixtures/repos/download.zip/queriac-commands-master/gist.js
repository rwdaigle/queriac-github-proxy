// Github - Create a new Gist

/*
Weâ€™d love versioning. Weâ€™d love SSL on our private pastes. Weâ€™d love to fork existing pastes. And you know what, weâ€™d love to push and pull our pastes using Git. Well, say hello to Gist.
*/

location = "http://gist.github.com/";