// TorrentSpy Quicksearch

http://www.torrentspy.com/search.asp?query=(q)