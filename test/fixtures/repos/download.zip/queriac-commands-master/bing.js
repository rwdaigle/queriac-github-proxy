// Bing Search

/*
Bing's a new search engine from Microsoft that's getting a lot of attention.
*/

location = "http://www.bing.com/search?q="+args.join(" ");