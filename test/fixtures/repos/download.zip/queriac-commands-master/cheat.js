// Cheat (Err the Blog)

/*
A web-based alternative to Err the Blogs's commandline gem, Cheat. Cheat sheets are basically wiki pages accessible from the command line. You can browse, add, or edit cheat sheets. Try to keep them concise. For a style guide, check out the cheat cheat sheet.

Read more at http://cheat.errtheblog.com/
*/

location = "http://cheat.errtheblog.com/s/"+args[0];