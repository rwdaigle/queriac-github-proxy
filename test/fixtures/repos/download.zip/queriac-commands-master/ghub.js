// Redirect to a npm package's GitHub page, if available.

location="https://ghub.io/"+args[0];