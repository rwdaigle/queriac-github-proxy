// Google Maps - Zeke Spots in Provence, France

http://maps.google.com/maps/ms?ie=UTF8&msa=0&msid=115099215088735124331.000457061f29bca7caf51&ll=43.866218,5.982056&spn=3.148344,7.141113&z=8