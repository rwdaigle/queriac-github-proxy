// Google "I'm Feeling Lucky"

/*
Jumps to Google's first search result for the query you've entered.
*/

location = "http://www.google.com/search?btnI=I'm%20Feeling%20Lucky&q="+args.join(" ");