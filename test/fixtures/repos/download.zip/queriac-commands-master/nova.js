// Mininova Torrent Search

/*
Mininova is one of the largest torrent listing sites. The site started in January 2005 as a successor to the (at that time very popular) Suprnova.org, which went offline at the end of 2004 due to legal issues. It is a directory and search engine for many kinds of torrent files.
*/

http://www.mininova.org/search/?search=(q)