// word reference

/*
word reference, fren port span fren & just E
*/

http://www.wordreference.com/