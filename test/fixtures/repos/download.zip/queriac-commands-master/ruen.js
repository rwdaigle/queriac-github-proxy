// Translate Russian to English

http://www.wordreference.com/ruen/(q)