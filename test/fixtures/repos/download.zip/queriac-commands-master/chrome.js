// Google Chrome Store Search

location="https://chrome.google.com/webstore/search/"+args.join(' ');