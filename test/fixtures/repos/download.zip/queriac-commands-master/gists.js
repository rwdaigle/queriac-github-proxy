// GitHub - My Gists

location = 'http://gist.github.com/mine';