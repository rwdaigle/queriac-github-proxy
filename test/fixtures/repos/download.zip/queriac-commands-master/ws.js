// Translate a Word or Term to Many Languages (Wikislate)

/*
Translate using Wikipedia and Google-did-you-mean. Read more at http://www.bonf.net/2007/06/09/translation-through-wikipedia/

ws vegetarian
ws -l fr conard
ws -l es muÃ±eca
*/

http://wikislate.com/index.php?source=[:language]&term=(q)