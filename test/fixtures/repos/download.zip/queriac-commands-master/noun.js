// The Noun Project

/*
Vector icon search
*/

location="http://thenounproject.com/search/?q="+args.join(" ");