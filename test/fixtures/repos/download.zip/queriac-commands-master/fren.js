// Translate French to English (WordReference.com)

location = "http://wordreference.com/fren/"+args.join(" ");