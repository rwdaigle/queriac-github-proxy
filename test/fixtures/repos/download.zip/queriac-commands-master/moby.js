// Moby Thesaurus at dict.org

/*
The Moby Thesaurus II contains 30,260 root words, with 2,520,264 synonyms and related terms - an average of 83.3 per root word. Each line consists of a list of comma-separated values, with the first term being the root word, and all following words being related terms.

More info at http://en.wikipedia.org/wiki/Moby_Project
*/

location="http://www.dict.org/bin/Dict?Form=Dict1&Strategy=*&Database=moby-thes&Query="+args.join(" ");