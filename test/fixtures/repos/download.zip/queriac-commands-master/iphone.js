// iPhone Queriac Bookmarklet

javascript: qq = prompt('Enter a Queriac Command', '');if (qq) location.href = 'http://queri.ac/[:user]/' + escape(qq)