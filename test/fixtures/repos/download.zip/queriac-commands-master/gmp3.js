// Google MP3 Search

/*
Use google to find what appear to be Apache Indexes of mp3 files, containing an "Index of" header.
*/

http://www.google.com/search?complete=1&q=-inurl:htm%20-inurl:html%20intitle:%22index%20of%22%20mp3%20%22(q)%22