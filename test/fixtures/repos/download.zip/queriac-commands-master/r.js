// Google Reader

location = 'http://google.com/reader'