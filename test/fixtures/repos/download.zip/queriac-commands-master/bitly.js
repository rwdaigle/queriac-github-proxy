// Generate bit.ly URL for the Current Page

/*
A new and improved alternative to TinyURL. Use bit.ly to generate a shorter version of the current URL.
*/

var e=document.createElement('script');
e.setAttribute('language','javascript');
e.setAttribute('src','http://bit.ly/bookmarklet/load.js');
document.body.appendChild(e);
void(0);
