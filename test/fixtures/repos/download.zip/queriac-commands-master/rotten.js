// QuickRotten

/*
A minimalist interface for Rotten Tomatoes movies reviews
*/

location = "http://quickrotten.com/?q="+args.join(" ");