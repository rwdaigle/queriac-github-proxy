// Google Reader Search

/*
Search your Google Reader feeds.
*/

location = 'http://www.google.com/reader/view/#search/'+args.join(" ");