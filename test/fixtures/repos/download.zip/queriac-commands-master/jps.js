// jQuery Plugin Search

http://www.google.com/search?hl=en&q=site%3Aplugins.jquery.com+(q)