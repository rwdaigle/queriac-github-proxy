// RubyGems Search

location = "http://rubygems.org/gems/"+args[0];