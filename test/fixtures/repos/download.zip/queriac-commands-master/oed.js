// OED Quicksearch

/*
You need to have an account with them to use this service.
*/

http://dictionary.oed.com/cgi/findword?query_type=word&queryword=(q)