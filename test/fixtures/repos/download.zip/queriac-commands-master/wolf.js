// Wolfram|Alpha

/*
Wolfram|Alpha is a computational knowledge engine: it generates output by doing computations from its own internal knowledge base, instead of searching the web and returning links. For examples, see http://www53.wolframalpha.com/examples/
*/

http://www53.wolframalpha.com/input/?i=(q)