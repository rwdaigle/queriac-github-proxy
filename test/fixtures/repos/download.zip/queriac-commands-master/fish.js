// Heroku Fishing Pole Search

location='https://vault-reports.herokuapp.com/fishing-pole/'+args[0];