// Heroku Addon Search

/*
Jump to a heroku addon page by permalink/slug
*/

location="https://addons.heroku.com/marketplace/addons/"+args[0];