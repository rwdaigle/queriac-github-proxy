// Amazon MP3 Search

/*
Search for downloadable music on Amazon
*/

location="http://www.amazon.com/s/ref=ntt_srch_drd_B0073QR2LO?ie=UTF8&index=digital-music&search-type=ss&field-keywords="+args.join(' ');