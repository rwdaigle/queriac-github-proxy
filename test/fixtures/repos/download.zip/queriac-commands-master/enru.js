// Translate English to Russian

http://www.wordreference.com/enru/(q)