// Spanish Synonyms

http://www.wordreference.com/sinonimos/(q)