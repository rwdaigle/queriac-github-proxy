// Translate English to Spanish (WordReference.com)

location = 'http://www.wordreference.com/es/translation.asp?tranword='+args.join(" ");