// Anagram Solver

/*
An anagram is a type of word play, the result of rearranging the letters of a word or phrase to produce a new word or phrase, using all the original letters exactly once; e.g., orchestra = carthorse. Use this command to solve them!
*/

location = "http://www.ssynth.co.uk/~gay/cgi-bin/nph-an?words=1&dict=antworth&doai=on&line="+args.join(" ")
