// View Cookies

alert('Cookies%20stored%20by%20this%20host%20or%20domain:%5Cn%5Cn'%20+%20document.cookie.replace(/;%20/g,'%5Cn'))
