// Wush Ticket Quickjump

https://wush.net/trac/[:project]/ticket/(q)