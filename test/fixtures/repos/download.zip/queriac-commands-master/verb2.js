// Verb Conjugation

http://humanities.uchicago.edu/orgs/ARTFL/forms_unrest/inflect.query.html