// npm Search

location="https://npmjs.org/search?q="+args.join(" ");