// Google Image Search

location = 'https://www.google.com/search?tbm=isch&q='+args.join(" ");