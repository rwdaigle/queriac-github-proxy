// Yahoo! Search

/*
Regular old Yahoo search.
*/

http://search.yahoo.com/search?p=(q)