// Twitter User Quickjump

/*
Jump to a twitter user's page.

Usage: tu zeke
*/

location = 'http://twitter.com/'+args[0];