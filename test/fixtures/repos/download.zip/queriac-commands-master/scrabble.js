// Scrabble Cheat-o-Matic

/*
To use the Scrabble cheat-o-matic, enter the letters you have below. Add any additional letters of places on the board that look promising to get a list of all the possible words that you can play. The Scrabble cheat-o-matic only handles single blank tiles, so in the unlikely event you have both blanks, tough. To enter a blank tile, use the _ (underscore) character.
*/

http://spod.cx/cheat-o-matic.shtml?letters=(q)&dict=sowpods&Cheat=Cheat