// Hipster Ipsum | Artisanal filler text for your site or project.

http://hipsteripsum.me/?paras=4&type=hipster-centric