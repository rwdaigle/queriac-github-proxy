// OneLook Reverse Dictionary

/*
Find a word by giving the definition. You can also use it to find crossword puzzle answers.

Examples..
rd barrel maker ("cooper")
rd museum guide ("docent")
rd m?z??t:composer ("Mozart")
rd sat*:composer ("Satie")
*/

http://www.onelook.com/?clue=(q)