// Heroku Devcenter: I'm Feeling Lucky

location = "https://devcenter.heroku.com/articles/"+args[0]