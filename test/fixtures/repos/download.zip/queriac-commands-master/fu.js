// Flickr User Quickjump

location = 'http://flickr.com/photos/'+args[0];