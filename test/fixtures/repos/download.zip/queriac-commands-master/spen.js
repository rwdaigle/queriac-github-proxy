// spanish to english 

/*
span to eng word ref
*/

http://www.wordreference.com/es/en/translation.asp?spen=