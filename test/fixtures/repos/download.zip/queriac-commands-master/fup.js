// Flickr Upload Page

/*
Just a quick hop to the Flickr Upload page.
*/

location = "http://flickr.com/photos/upload/";