// Github Lucky

location="http://www.google.com/search?btnI=I'm%20Feeling%20Lucky&q=site:github.com "+args.join(" ");