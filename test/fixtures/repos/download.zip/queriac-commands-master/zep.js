// Inject Zepto

(function(){
  var s=document.createElement('script');
  s.setAttribute('src','https://queriac2.herokuapp.com/zepto.min.js');
  document.getElementsByTagName('head')[0].appendChild(s);
})();