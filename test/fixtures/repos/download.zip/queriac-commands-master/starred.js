// Starred Gmail

location = "http://mail.google.com/mail/?search=query&view=tl&start=0&init=1&fs=1&q=is%3Astarred";     