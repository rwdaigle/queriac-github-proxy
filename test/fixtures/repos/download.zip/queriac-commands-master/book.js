// BookFinder.com Search by Title

/*
BookFinder.com is a one-stop ecommerce search engine that searches over 150 million books for saleâ€”new, used, rare, out-of-print, and textbooks. We save you time and money by searching every major catalog online, and letting you know which booksellers are offering the best prices and selection. When you find a book you like, you can buy it directly from the original seller; we never charge a markup.
*/

location="http://www.bookfinder.com/search/?author=&lang=en&submit=Begin+search&new_used=*&destination=us&currency=USD&mode=basic&st=sr&ac=qr&title="+args.join(" ")
