// Google - Web History

/*
If you let it, Google archives your search history. Use this command to search your search history. How meta!
*/

http://www.google.com/history/find?q=(q)