// gTalk: New Message to Buddy

javascript:document.location.href='gtalk:chat?jid=(q)'