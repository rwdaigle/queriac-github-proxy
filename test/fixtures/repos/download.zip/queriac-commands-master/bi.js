// Bing Image Search

/*
Bing is a new search engine from Microsoft. The web search is pretty standard, but the image search has some nice features that set it apart from Google, Yahoo, and the others.
*/

location = "http://www.bing.com/images/search?q="+args.join(" ");