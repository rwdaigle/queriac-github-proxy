// Stock.Xchng

/*
Huge collection of free/cheap stock photography.
*/

http://www.sxc.hu/browse.phtml?txt=(q)&f=search&w=1