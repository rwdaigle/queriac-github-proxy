// eng to span

/*
eng to span word ref
*/

http://www.wordreference.com/es/translation.asp?tranword=&dict=enes&B10=Search