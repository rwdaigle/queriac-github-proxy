// ZipSkinny - Zip Code Info

/*
Get demographic information for US zip codes
*/

http://zipskinny.com/index.php?zip=(q)