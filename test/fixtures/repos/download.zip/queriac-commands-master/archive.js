// Archive.org Quicksearch

/*
The Internet Archive (IA) is a non-profit organization dedicated to maintaining an on-line library and archive of Web and multimedia resources. Located at the Presidio in San Francisco, California, this archive includes "snapshots of the World Wide Web" (archived copies of pages, taken at various points in time), software, movies, books, and audio recordings.
*/

location="http://www.archive.org/search.php?query="+args.join(" ")
