// Latin to English Translation

/*
Translate Latin to English.

Usage: laen mitis
*/

http://arts.cuhk.edu.hk/cgi-bin/aglimpse-latin/16/www/Lexis/Latin?query=(q)&case=on&whole=on&errors=0