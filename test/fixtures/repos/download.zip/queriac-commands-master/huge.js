// Big Huge Thesaurus

/*
This site is based on source data from the Princeton University WordNet database, the Carnegie Mellon Pronouncing Dictionary, and suggestions from thousands of people on the internet just like you.
*/

http://words.bighugelabs.com/(q)