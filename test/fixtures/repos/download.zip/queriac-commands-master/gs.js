// Github Search

location="https://github.com/search?type=Code&q="+args.join(' ');