// Tweet to Twitter

/*
Post to twitter right from the address bar.
*/

http://twitter.com/statuses/update.xml?status=(q)