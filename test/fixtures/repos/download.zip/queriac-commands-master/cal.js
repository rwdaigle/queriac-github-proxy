// Google Calendar

location = "http://www.google.com/calendar/render";