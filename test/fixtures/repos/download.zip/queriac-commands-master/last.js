// Last.fm Music Search

/*
Search Last.fm
*/

http://www.last.fm/music/?q=(q)