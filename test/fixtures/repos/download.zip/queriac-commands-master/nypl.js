// NYPL Digital Gallery Search

/*
NYPL Digital Gallery provides access to over 600,000 images digitized from primary sources and printed rarities in the collections of The New York Public Library, including illuminated manuscripts, historical maps, vintage posters, rare prints  and photographs, illustrated books, printed ephemera, and more.
*/

http://digitalgallery.nypl.org/nypldigital/dgkeysearchresult.cfm?keyword=(q)