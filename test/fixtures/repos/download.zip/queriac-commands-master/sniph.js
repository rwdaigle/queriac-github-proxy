// Sniphr Search

location = "http://sniphr.com/sniphs?q="+args.join(" ");