// Instapaper - Unread

/*
Open your unread Instapaper links
*/

location = "http://www.instapaper.com/u";