// Last.fm - Jump to Artist

/*
Jump to an artist on Last.fm

Usage
artist Pink Anderson
*/

http://www.last.fm/music/(q)