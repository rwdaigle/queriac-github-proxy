// OneLook Dictionary Search

/*
If you don't know the right word to use, we'll help you find it. No word is too obscure: More than 5 million words in more than 900 online dictionaries are indexed by the OneLook search engine.
*/

http://www.onelook.com/?ls=a&w=(q)