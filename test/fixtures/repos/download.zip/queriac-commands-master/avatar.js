// Zeke's avatar on Flickr

location="http://www.flickr.com/photos/sikelianos/3322146088/"
