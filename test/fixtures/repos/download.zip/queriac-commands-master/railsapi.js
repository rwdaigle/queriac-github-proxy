// Rails Framework Documentation

http://api.rubyonrails.org/