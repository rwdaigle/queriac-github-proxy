// Google Multilanguage Define

/*
Provides definitions to your query in multiple languages.
*/

http://www.google.com/search?hl=en&lr=&oi=definel&defl=all&q=define: (q)