// New Queriac Command

location="https://www.queriac.com/users/zeke/commands/new";