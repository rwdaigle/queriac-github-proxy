// Edit Addon

location = "https://addons.heroku.com/marketplace/addons/"+ args[0] + "/edit";