// Google Maps - Paris Markets

http://maps.google.com/maps/ms?hl=en&ie=UTF8&msa=0&msid=115099215088735124331.000434b5375b280f734d0&ll=48.856358,2.34026&spn=0.044895,0.11158&z=14