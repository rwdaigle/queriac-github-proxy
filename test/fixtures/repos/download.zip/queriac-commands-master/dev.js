// Heroku Dev Center

location = "https://devcenter.heroku.com/articles?q="+args.join(" ");