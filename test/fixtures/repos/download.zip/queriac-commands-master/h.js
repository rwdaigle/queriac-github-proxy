// Search Local Chrome History

/*
Search your Google Chrome browsing history
*/

chrome://history/#q=(q)