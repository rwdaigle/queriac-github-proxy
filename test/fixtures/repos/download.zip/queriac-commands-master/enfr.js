// Translate English to French

location = "http://wordreference.com/enfr/"+args.join(" ");