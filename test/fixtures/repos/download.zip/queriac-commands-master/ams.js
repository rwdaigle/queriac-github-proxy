// Amazon MP3 Quicksearch

/*
Amazon's answer to iTunes, AmazonMP3 serves up 256kbps DRM-free MP3s for 99 cents each.
*/

location="http://www.amazon.com/s/ref=nb_ss_dm_hp_nav_lk/002-8722033-4232026?initialSearch=1&url=search-alias%3Ddigital-music&field-keywords="+args.join(" ")
