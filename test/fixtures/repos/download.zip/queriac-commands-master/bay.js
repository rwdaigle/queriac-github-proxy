// Pirate Bay Search

/*
The Pirate Bay is a Swedish website that indexes and tracks BitTorrent ("torrent") files. It bills itself as "the world's largest BitTorrent tracker"[1] and is ranked as the 98th most popular website by Alexa Internet.[2] The website is primarily funded with advertisements shown next to torrent listings. Initially established in November 2003 by the Swedish anti-copyright organization PiratbyrÃ¥n ("The Piracy Bureau"), it has been operating as a separate organization since October 2004.
*/

location = "http://thepiratebay.org/search/"+args.join(" ");