// Yahoo Messenger: New Message to Buddy

javascript:document.location.href='ymsgr:sendIM?(q)'