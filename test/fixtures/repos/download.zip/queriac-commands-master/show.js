// Show Queriac Command

location = "https://www.queriac.com/users/zeke/commands/"+args[0];