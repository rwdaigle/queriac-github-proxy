// uChicago French Verb Conjugator

/*
- Enter a French verb (in the infinitive) and press the "Conjugate" button to see the forms of the verb for the tenses you have selected.
- If you cannot enter accented characters directly, you may use the following symbols after the character in question to indicate an accent:

\ for grave		a\ becomes Ã 
/ for aigu	e/ becomes Ã©
^ for circonflexe	e^ becomes Ãª
, for cedille	c, becomes Ã§
" for trema	o" becomes Ã¶
*/

http://machaut.uchicago.edu/?action=search&resource=conjugator&verb=(q)