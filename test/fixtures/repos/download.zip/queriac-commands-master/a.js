// Search Amazon

/*
Searches all of amazon.com
*/

location = "http://www.amazon.com/s/ref=nb_sb_noss_2?field-keywords="+args.join(" ")
