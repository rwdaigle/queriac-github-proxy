// Namecheap Domain Search

location = "http://www.namecheap.com/domains/domain-name-search/results.aspx?domain="+args[0];