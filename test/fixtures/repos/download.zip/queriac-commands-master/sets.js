// My Photosets on Flickr

location = "http://www.flickr.com/photos/sikelianos/sets/";