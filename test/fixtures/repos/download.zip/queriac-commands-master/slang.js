// Urban Dictionary

location = 'http://www.urbandictionary.com/define.php?term='+args.join(" ");