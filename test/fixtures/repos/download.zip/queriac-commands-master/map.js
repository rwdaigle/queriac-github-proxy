// Google Maps Search

location = 'https://maps.google.com/maps?q='+args.join(" ");