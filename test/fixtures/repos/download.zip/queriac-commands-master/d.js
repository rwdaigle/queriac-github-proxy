// Del.icio.us Tag Search (All)

location="http://del.icio.us/tag/"+args.join(" ")
