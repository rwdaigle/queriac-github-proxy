// Google Groups Jump

location="https://groups.google.com/a/heroku.com/forum/#!forum/" + args[0]