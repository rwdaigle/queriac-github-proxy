// Translate English to German or German to English (Beolingus)

/*
Enter a term in German or English.. it translates in both directions simultaneously. A little history.. Since 1995 our online dictionary has offered you German <> English translations: fast, efficient, user-friendly and, of course, free. We chose the BEO (German for Hill Myna) as our symbol, because this amazing bird is a very communicative one, gathering and imitating words and noises. The word "Beo" comes from Indonesia and means "chatterbox". In South-Eastern Asia, the Beo is well known as a really communicative buddy, which talks a lot to its companions.
*/

location="http://dict.tu-chemnitz.de/dings.cgi?lang=en&service=deen&query="+args.join(" ")
