// Translate Italian to English (WordReference.com)

window.location-"http://www.wordreference.com/iten/"+args.join(" ");