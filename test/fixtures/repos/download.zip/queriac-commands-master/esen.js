// Translate Spanish to English (WordReference.com)

location = 'http://www.wordreference.com/es/en/translation.asp?spen='+args.join(" ");