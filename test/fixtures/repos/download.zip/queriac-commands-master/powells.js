// Powell's Book Search

/*
Powell's Books, with seven different locations, is in the Portland metropolitan area (with roots in Chicago, Illinois). Powell's headquarters location, Powell's City of Books, claims to be the largest independent new and used bookstore in the world.

http://en.wikipedia.org/wiki/Powell%27s_Books
*/

location = "http://www.powells.com/s?kw="+args.join(" ");