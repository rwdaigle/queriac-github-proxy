// Google Search

location = 'http://google.com/search?q='+args.join(' ');