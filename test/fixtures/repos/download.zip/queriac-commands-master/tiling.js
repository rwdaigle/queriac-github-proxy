// Tiling Backgrounds - a set on Flickr

/*
A Flickr collection of tiling background images.
*/

location = "http://www.flickr.com/photos/sikelianos/sets/72157594233031615/";