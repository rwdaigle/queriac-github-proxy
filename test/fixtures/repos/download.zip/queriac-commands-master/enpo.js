// Translate English to Portuguese

http://dictionary.reverso.net/english-portuguese/(q)