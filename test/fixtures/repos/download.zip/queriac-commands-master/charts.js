// Last.fm Charts - User Search

/*
Show recent listening history for a last.fm user

Usage
lu sikelianos
*/

location="http://www.last.fm/user/" + args[0] + "/charts/?charttype=recenttracks"
