// Show Hidden Forms Fields

(function(){var i,f,j,e,div,label,ne; for(i=0;f=document.forms[i];++i)for(j=0;e=f[j];++j)if(e.type==%22hidden%22){ D=document; function C(t){return D.createElement(t);} function A(a,b){a.appendChild(b);} div=C(%22div%22); label=C(%22label%22);