// Ninjawords Search

/*
Ninjawords is a fast interface to Wiktionary. You can compare definitions by looking up many words at once by separating them with commas.

Usage
ninja copacetic
ninja adroit,deft,cunning
*/

http://ninjawords.com/(q)