// Open BuiltWith Profile for Current Page

/*
What's that site running? Use BuiltWith to discover the application framework, language and CMS tools behind a website.
*/

location = 'http://builtwith.com?'+location.href
