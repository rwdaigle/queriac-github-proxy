// Duck Duck Go

/*
DuckDuckGo is a search engine, like Google.
*/

location = "http://duckduckgo.com/?q="+args.join(" ");