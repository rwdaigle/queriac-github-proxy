// Wordnik Search

/*
An ongoing project devoted to discovering all the words and everything about them.
*/

location = "http://www.wordnik.com/words/"+args.join(" ");