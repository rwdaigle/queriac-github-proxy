// I'm Feeling Lucky for Wikipedia

location = "http://www.google.com/search?btnI=I'm%20Feeling%20Lucky&q=site:en.wikipedia.org "+args.join(" ");