// Sunrise & Sunset Times by Zip Code

/*
Get today's sunrise and sunset times by entering your zip zode.
*/

http://www.calendar-updates.com/sun.asp?PostalCode=(q)