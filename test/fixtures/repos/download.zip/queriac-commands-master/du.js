// Delicious User Quickjump

/*
Jump to a user's page on Delicious
*/

http://delicious.com/(q)