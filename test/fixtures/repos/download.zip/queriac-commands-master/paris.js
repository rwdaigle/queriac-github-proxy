// Google Maps - Zeke Spots in Paris

http://maps.google.com/maps/ms?hl=en&ie=UTF8&msa=0&msid=115099215088735124331.00000113078c8c9f11c37&ll=48.863134,2.3594&spn=0.044889,0.11158&z=14