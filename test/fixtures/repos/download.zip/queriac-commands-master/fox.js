// Firefox Add-ons Search

/*
Add-ons extend Firefox, letting you personalize your browsing experience. Take a look around and make Firefox your own.
*/

https://addons.mozilla.org/en-US/firefox/search?q=(q)&cat=all