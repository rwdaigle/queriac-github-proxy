// Gmail Search

location = "https://mail.google.com/mail/u/0/#search/"+args.join(" ");