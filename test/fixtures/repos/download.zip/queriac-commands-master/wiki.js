// Wikipedia Search (using Google)

/*
adds site:en.wikipedia.org to your Google search
*/

location = "http://www.google.com/search?q=site:en.wikipedia.org%20"+args.join(" ");