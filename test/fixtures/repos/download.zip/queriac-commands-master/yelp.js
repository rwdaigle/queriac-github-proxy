// Yelp Search

var loc = loc || 94110; // SF Mission
location = "http://www.yelp.com/search?find_loc="+loc+"&find_desc="+args.join(" ");