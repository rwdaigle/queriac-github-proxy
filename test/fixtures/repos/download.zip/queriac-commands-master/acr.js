// Acronym Quicksearch

location="http://www.acronymfinder.com/af-query.asp?p=dict&String=exact&Acronym="+args.join(" ")
