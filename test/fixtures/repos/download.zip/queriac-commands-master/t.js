// Twitter Shortcut

/*
Just a quick jump to Twitter Home.
*/

http://twitter.com/home