// Del.icio.us History for the Current Page (in a new window)

/*
Used to be javascript:location.href='http://del.icio.us/url/check?url='+encodeURIComponent(location.href) , which uses the current window.
*/

javascript:void(open('http://del.icio.us/url/check?show=notes_only&url='+encodeURIComponent(location.href)));