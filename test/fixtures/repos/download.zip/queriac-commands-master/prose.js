// Prose Generator

/*
Generates a random collection of sentences (defaults to 3), presumably from some antiquarian novel..
*/

http://jonathanaquino.com/austen.php?sentences=(q)