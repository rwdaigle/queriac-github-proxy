// Netflix Search

location = "http://movies.netflix.com/WiSearch?v1="+args.join(" ");