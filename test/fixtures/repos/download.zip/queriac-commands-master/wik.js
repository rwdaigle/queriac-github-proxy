// Wiktionary Word Lookup

location = "http://en.wiktionary.org/wiki/"+args.join(" ");