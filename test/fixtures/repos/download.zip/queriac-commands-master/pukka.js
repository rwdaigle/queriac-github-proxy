// Open Pukka for Current Page

/*
Pukka is a minimalist client for del.icio.us. Fire it up and within seconds you can easily post to one or more del.icio.us accounts. Think of it as a mini blogging application. You can even set Pukka as your external weblog client in NetNewsWire, NewsFire, or Vienna.
*/

javascript:document.location.href='pukka:url='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title)+'&extended='+encodeURIComponent(window.getSelection());